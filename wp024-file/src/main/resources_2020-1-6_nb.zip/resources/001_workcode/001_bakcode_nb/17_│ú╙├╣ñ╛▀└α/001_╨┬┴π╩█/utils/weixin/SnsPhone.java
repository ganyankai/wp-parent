package com.zrytech.framework.newshop.utils.weixin;

import lombok.Data;

@Data
public class SnsPhone {

    private String phoneNumber;
}
