package cn.dante.pattern.ty02adapter;

public interface ISuperUser {
    public String fly();
}
