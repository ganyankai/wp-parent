package cn.dante.pattern.ty08iterator;

public interface IProject {
    //从老板这里看到的就是项目信息
    public String getProjectInfo();
}