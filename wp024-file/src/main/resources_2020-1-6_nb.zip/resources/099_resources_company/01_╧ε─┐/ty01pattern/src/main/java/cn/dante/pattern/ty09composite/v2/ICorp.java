package cn.dante.pattern.ty09composite.v2;

public interface ICorp {
    //每个员工都有信息，你想隐藏，门儿都没有！
    public String getInfo();
}