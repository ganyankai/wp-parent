package cn.dante.pattern.ty01facade.study;

public class Police {

    public void checkLetter(LetterProcess letterProcess) {

    }
}
