package cn.dante.pattern.ty09composite;

public interface ILeaf {
    //获得自己的信息呀
    public String getInfo();
}