package cn.dante.pattern.ty10_observer;

/**
 * @author cbf4Life cbf4life@126.com
 * I'm glad to share my knowledge with you all.
 * 类似于李斯的这种人，现代嘛叫做偷窥狂
 */
public interface ILiSi {
    //一发现别人有动静，自己也要行动起来
    public void update(String context);
}