package cn.dante.pattern.ty08iterator.v2;

import java.util.Iterator;

public interface IProjectIterator extends Iterator {

}